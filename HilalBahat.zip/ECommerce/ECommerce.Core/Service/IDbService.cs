﻿using ECommerce.Core.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Core.Service
{
    public interface IDbService<T> where T : CoreEntity
    {
        
        bool Add(T entity);

        bool Update(T entity);

        bool Delete(T entity);

        List<T> GetAll();

        T GetBy(int id);

        bool Save();
    }
}
