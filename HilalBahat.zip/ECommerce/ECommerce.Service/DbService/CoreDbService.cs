﻿using ECommerce.Core.Entity;
using ECommerce.Core.Service;
using ECommerce.Model.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Service.DbService
{
    public class CoreDbService<T> : IDbService<T> where T : CoreEntity
    {
        private readonly ECommerceContext _db;

        public CoreDbService(ECommerceContext db)
        {
            _db = db;
        }

        public bool Add(T entity)
        {
            try
            {
                _db.Set<T>().Add(entity);
                return Save();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(T entity)
        {
            try
            {
                _db.Set<T>().Remove(entity);
                return Save();
            }
            catch (Exception)
            {
                return false;
            }
        }

    
        public List<T> GetAll()
        {
            return _db.Set<T>().ToList();
        }

        public T GetBy(int id) => _db.Set<T>().Find(id);


        public bool Save()
        {
            return _db.SaveChanges() > 0 ? true : false;
        }

        public bool Update(T entity)
        {
            try
            {
                _db.Set<T>().Update(entity);
                return Save();
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
    }


