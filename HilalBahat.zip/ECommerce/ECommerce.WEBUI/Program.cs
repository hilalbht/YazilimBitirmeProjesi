using ECommerce.Core.Service;
using ECommerce.Model.Context;
using ECommerce.Model.Entities;
using ECommerce.Service.DbService;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMvc();

builder.Services.AddDbContext<ECommerceContext> (options =>
            {
                options.UseSqlServer("Server=LAPTOP-7U3RNHMT\\SQLEXPRESS;Database=ECommerce;Integrated Security=True;TrustServerCertificate=True;");
            });

builder.Services.AddScoped(typeof(IDbService<>), typeof(CoreDbService<>));


// Add services to the container.
builder.Services.AddRazorPages().AddRazorRuntimeCompilation();

builder.Services.AddSession(options =>
{
    options.Cookie.Name = "Basket";
    options.IdleTimeout = TimeSpan.FromMinutes(45);
    options.Cookie.HttpOnly = true;
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseSession();
app.UseRouting();

app.UseAuthorization();

app.MapAreaControllerRoute(
               name: "Admin",
               areaName: "Admin",
               pattern: "Admin/{Controller=Home}/{Action=Index}/{id?}"
           );

app.MapControllerRoute(
              name: "default",
              pattern: "{Controller=Home}/{Action=Index}/{id?}"
          );

app.Run();



