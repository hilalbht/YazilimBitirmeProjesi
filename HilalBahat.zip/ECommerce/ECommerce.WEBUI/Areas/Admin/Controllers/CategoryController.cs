﻿using ECommerce.Core.Service;
using ECommerce.Model.Entities;
using Microsoft.AspNetCore.Mvc;

namespace ECommerce.WEBUI.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private readonly IDbService<Category> _db;

        public CategoryController(IDbService<Category> db)
        {
            _db = db;
        }

        public IActionResult GetAllCategory()
        {
            return View(_db.GetAll());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Category c)
        {
            if (c != null)
            {
                return _db.Add(c) ? RedirectToAction("GetAllCategory") : View();
            }

            return View();
        }

        public IActionResult Update(int id)
        {
            return View(_db.GetBy(id));
        }

        [HttpPost]
        public IActionResult Update(Category c)
        {
            var record = _db.GetBy(c.ID);
            if (record != null)
            {
                record.CategoryName = c.CategoryName;
                record.CategoryDescription = c.CategoryDescription;

                return _db.Update(record) ? RedirectToAction("GetAllCategory") : View();
            }

            return View();
        }

        public IActionResult Delete(int id)
        {
            if (id > 0)
            {
                return _db.Delete(_db.GetBy(id)) ? RedirectToAction("GetAllCategory") : View();
            }

            return View();
        }


    }
}
