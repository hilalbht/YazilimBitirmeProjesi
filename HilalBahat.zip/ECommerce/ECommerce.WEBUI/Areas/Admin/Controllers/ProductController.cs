﻿using ECommerce.Core.Service;
using ECommerce.Model.Entities;
using Microsoft.AspNetCore.Mvc;

namespace ECommerce.WEBUI.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ProductController : Controller
    {
        private readonly IDbService<Product> _db; 
        private readonly IDbService<Category> _dbCategory;

        public ProductController(IDbService<Product> db, IDbService<Category> dbCategory)
        {
            _db = db;
            _dbCategory = dbCategory;
        }

        public IActionResult GetAllProduct()
        {
            return View(_db.GetAll());
        }

        public IActionResult CreateProduct()
        {
            ViewBag.KategoriListesi = _dbCategory.GetAll(); 

            return View();
        }

        [HttpPost]
        public IActionResult CreateProduct(Product p, IFormFile file)
        {
            if (p != null)
            {
                string fileName = Path.GetFileName(file.FileName); 
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                p.ProductImage = fileName;

                return _db.Add(p) ? RedirectToAction("GetAllProduct") : View();
            }

            return View();
        }

        public IActionResult UpdateProduct(int id)
        {
            ViewBag.KategoriListesi = _dbCategory.GetAll(); 

            return View(_db.GetBy(id));
        }
        [HttpPost]
        public IActionResult UpdateProduct(Product p, IFormFile file)
        {
            var record = _db.GetBy(p.ID);

            if (record != null)
            {
                string fileName = string.Empty;

                if (file != null)
                {
                    fileName = Path.GetFileName(file.FileName); 
                    string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }

                record.ProductImage = (fileName == string.Empty) ? record.ProductImage : fileName;
                record.ProductName = p.ProductName;
                record.ProductPrice = p.ProductPrice;
                record.ProductStock = p.ProductStock;
                record.ProductDescription = p.ProductDescription;

                return _db.Update(record) ? RedirectToAction("GetAllProduct") : View();
            }

            return View();
        }

        public IActionResult DeleteProduct(int id)
        {
            if (id > 0)
            {
                return _db.Delete(_db.GetBy(id)) ? RedirectToAction("GetAllProduct") : View();
            }

            return View(_db.GetBy(id));

        }


    }
}
