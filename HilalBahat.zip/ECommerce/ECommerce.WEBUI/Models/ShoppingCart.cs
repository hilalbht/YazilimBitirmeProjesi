﻿namespace ECommerce.WEBUI.Models
{
    public class ShoppingCart
    {

        public List<ShoppingCartItem> shoppingCartItems { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
