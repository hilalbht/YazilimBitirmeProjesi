﻿namespace ECommerce.WEBUI.Models
{
    public class ShoppingCartItem
    {

        public int ID { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public decimal ProductPrice { get; set; }
        public int Quantity { get; set; }
        public decimal TotalAmount => ProductPrice * Quantity;
    }
}
