﻿using ECommerce.Model.Entities;
using ECommerce.WEBUI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace ECommerce.WEBUI.Controllers
{
    public class BasketController : Controller
    {
        //Sepet özeti
        public IActionResult Index()
        {
            var cartItems = GetShoppingCartItems();
            decimal total = 0;

            foreach (var cartItem in cartItems)
            {
                total += cartItem.TotalAmount;
            }

            var sc = new ShoppingCart()
            {
                shoppingCartItems = cartItems,
                TotalAmount = total
            };

            return View(sc);
        }


        public List<ShoppingCartItem> GetShoppingCartItems()
        {
            var cartItems = HttpContext.Session.GetString("cartItems");

            if (cartItems == null)
            {
                return new List<ShoppingCartItem>();
            }

            return JsonConvert.DeserializeObject<List<ShoppingCartItem>>(cartItems);


        }

        public IActionResult AddToCart(Product p, int Quantity = 1)
        {
           
            var cartItems = GetShoppingCartItems();
            AddProductToCart(cartItems, p, Quantity);

           
            Save(cartItems);

            return RedirectToAction("Index");
        }

        private void AddProductToCart(List<ShoppingCartItem> sc, Product urun, int adet)
        {
            var data = sc.FirstOrDefault(x => x.ID == urun.ID);

           
            if (data != null)
            {
                data.Quantity += adet;
            }
            else 
            {
                sc.Add(new ShoppingCartItem()
                {
                    ID = urun.ID,
                    ProductName = urun.ProductName,
                    ProductPrice = urun.ProductPrice,
                    Quantity = adet
                });
            }
        }


        public IActionResult Save(List<ShoppingCartItem> sc)
        {
            
            var data = JsonConvert.SerializeObject(sc);
            HttpContext.Session.SetString("cartItems", data);

            return RedirectToAction("Index");
        }


        public IActionResult CartClear()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Index");
        }

        public IActionResult RemoveToCart(int id, int Quantity = 1)
        {
            
            var cartItems = GetShoppingCartItems();

            RemoveProductToCart(cartItems, id, Quantity);

            
            Save(cartItems);

            return RedirectToAction("Index");
        }

        private void RemoveProductToCart(List<ShoppingCartItem> sc, int id, int quantity)
        {
            var data = sc.FirstOrDefault(x => x.ID == id);

            if (data != null)
            {
               
                if (data.Quantity > quantity)
                {
                    data.Quantity -= quantity;
                }
                else 
                {
                    sc.Remove(data);
                }
            }
        }
    }
}

    
