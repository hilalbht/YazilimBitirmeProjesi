﻿using ECommerce.Core.Service;
using ECommerce.Model.Entities;
using Microsoft.AspNetCore.Mvc;

namespace ECommerce.WEBUI.Controllers
{
    public class ProductController : Controller
    {
        private readonly IDbService<Product> _db;
        public ProductController(IDbService<Product> db)
        {
            _db = db;
        }
        public IActionResult Detail(int id)
        {
            return View(_db.GetBy(id));
        }
    }
}
