﻿using ECommerce.Core.Service;
using ECommerce.Model.Entities;
using Microsoft.AspNetCore.Mvc;

namespace ECommerce.WEBUI.Controllers
{
    public class CategoryController : Controller
    {
        private readonly IDbService<Product> _db;

        public CategoryController(IDbService<Product> db)
        {
            _db = db;
        }

        public IActionResult GetProductByCategory(int id)
        {
            return View(_db.GetAll().Where(x => x.CategoryId == id).ToList());
        }
    }
}
